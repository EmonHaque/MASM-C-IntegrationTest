#include <stdio.h>
#include "ASMHeader.h"

int main() {
	char* msg = "Hello there";
	printf("Length is: %d\n", stringLength(msg));

	int x = 100;
	doubleValue(&x);
	printf("Doubled value is: %d\n", x);

	int y = 300;
	printf("Addition result is: %d\n", addTwoValues(x, y));

	int values[] = { 10, 20, 30, 40, 50 };
	//printf("Sum of the array is: %d\n", addMultipleValues(5, values)); //count gets into rcx values into rax wher args are passed in this order
	printf("Sum of the array is: %d\n", addMultipleValues(values, sizeof values)); // values gets into rcx and size into rdx
	system("PAUSE");
	return 0;
}