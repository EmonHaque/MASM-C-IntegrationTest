#pragma once

int stringLength(char* text);
void doubleValue(int* x);
int addTwoValues(int, int);
int addMultipleValues(int*, int);